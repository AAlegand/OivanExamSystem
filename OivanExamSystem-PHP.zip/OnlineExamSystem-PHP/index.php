<!DOCTYPE >
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Oivan System </title>
<link  rel="stylesheet" href="css/bootstrap.min.css"/>
 <link  rel="stylesheet" href="css/bootstrap-theme.min.css"/>    
 <link rel="stylesheet" href="css/main.css">
 <link  rel="stylesheet" href="css/font.css">
 <script src="js/jquery.js" type="text/javascript"></script>

  <script src="js/bootstrap.min.js"  type="text/javascript"></script>
 	<link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
<?php if(@$_GET['w'])
{echo'<script>alert("'.@$_GET['w'].'");</script>';}
?>
<script>
function validateForm() {var y = document.forms["form"]["name"].value;	var letters = /^[A-Za-z]+$/;if (y == null || y == "") {alert("Name must be filled out.");return false;}var z =document.forms["form"]["college"].value;if (z == null || z == "") {alert("college must be filled out.");return false;}var x = document.forms["form"]["email"].value;var atpos = x.indexOf("@");
var dotpos = x.lastIndexOf(".");if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {alert("Not a valid e-mail address.");return false;}var a = document.forms["form"]["password"].value;if(a == null || a == ""){alert("Password must be filled out");return false;}if(a.length<5 || a.length>25){alert("Passwords must be 5 to 25 characters long.");return false;}
var b = document.forms["form"]["cpassword"].value;if (a!=b){alert("Passwords must match.");return false;}}
</script>


</head>
<style>
.select{
  width: 90%;
  padding: 10px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
/* Full-width input fields */
input[type=text], input[type=password] {
  width: 90%;
  padding: 10px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #0b0a0a;
  color: white;
  padding: 14px 20px;
  margin-left: 250px ;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}


.button1 {
  background-color: #0b0a0a;
  color: white;
  margin-left: 300px ;
  border: none;
  cursor: pointer;
  width: 50%;
  opacity: 0.9;
}

.button1:hover {
  opacity:1;
}


/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}


</style>
<script>
  function asd(a)
{
    if(a==2)
        document.getElementById("form1").style.display="block";
        document.getElementById("form2").style.display="none";   
}
function e(r)
{
  if(r==1)
      document.getElementById("form2").style.display="block"; 
      document.getElementById("form1").style.display="none";
}

</script>

<body>
<div class="header">
<div class="row">
<div class="col-lg-6">
<span class="logo">Oivan System</span></div>
<div class="col-md-2 col-md-offset-4">
<a href="#" class="pull-right btn sub1" style="border-radius:0%" href="#" data-toggle="modal" data-target="#login"><span class="glyphicon glyphicon-log-in" aria-hidden="true"></span>&nbsp;<span class="title1"><b>Login</b></span></a></div>
<!--sign in modal start-->
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content title1">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title title1 text-center"><span style="color:black"><b>USER LOGIN</b></span></h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" action="login.php?q=index.php" method="POST">
<fieldset>


<!-- Text input-->
<div class="form-group">
  <label class="col-md-3 control-label" for="email"></label>  
  <div class="col-md-6">
  <input id="email" name="email" placeholder="Email" class="form-control input-md" type="email">
    
  </div>
</div>


<!-- Password input-->
<div class="form-group">
  <label class="col-md-3 control-label" for="password"></label>
  <div class="col-md-6">
    <input id="password" name="password" placeholder="Password" class="form-control input-md" type="password">
    
  </div>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Log in</button>
		</fieldset>
</form>
</div>
</div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--sign in modal closed-->
</div><!--header row closed-->
</div>
<div style="">
<button type="button1" name="form1show" onclick="asd(2)" class="button1">Sign Up as a teacher</button>
<button type="button1" name="form2show" onclick="e(1)" class="button1">Sign Up as a student</button>
</div>
<div style="width:100%; height:100%; margin-top: 10px;">
<form action="index.php" method="POST" id="form2" style="border:1px solid #ccc; display: none; background-color:white;">
<div class="container">
  
 <center> <h1>Please fill in this form to Sing up as student.</h1></center>
  <hr>

  <input type="text" placeholder="Name" name="name" required>
  <select id="gender" class="select" name="gender" placeholder="Gender" required>
  <option value="Male">Male</option>
  <option value="Famale">Female</option></select>
  <input type="text" placeholder="Enter Email" name="email" required>
  <input type="text" placeholder="password" name="password" required>
  <div class="clearfix">
    <button type="submit" name="singupstudentbutton" class="signupbtn">Sign Up</button>
  </div>
</div>
</form>
<?php
include_once 'dbConnection.php';
if(isset($_POST['singupstudentbutton'])){
  $user_email = htmlentities(mysqli_real_escape_string($con,$_POST['email']));
	$gender= htmlentities(mysqli_real_escape_string($con,$_POST['gender']));
  $name = htmlentities(mysqli_real_escape_string($con,$_POST['name']));
	$user_password = htmlentities(mysqli_real_escape_string($con,$_POST['password']));
  $insert = "insert into user (email,gender,name,password) values ('$user_email','$gender','$name','$user_password')";

	$query = mysqli_query($con,$insert);

	if($query){

	echo "<script>alert('student has been added')</script>";


}}

?>

<form action="index.php" method="POST" id="form1" style="border:1px solid #ccc; display: none; background-color:white;">
<div class="container">
  
<center> <h1>Please fill in this form to Sing up as teacher.</h1></center>
  <hr>

  <input type="text" placeholder="Name" name="name" required>
  <select id="gender" class="select" name="gender" placeholder="Gender" required>
  <option value="Male">Male</option>
  <option value="Famale">Female</option></select>
  <select id="Role" class="select" name="Role" placeholder="Role" required>
  <option value="teacher">teacher</option>
   </select>
  <input type="text" placeholder="Enter Email" name="email" required>
  <input type="text" placeholder="password" name="password" required>
  <div class="clearfix">
    <button type="submit" name="singupteacherbutton" class="signupbtn">Sign Up</button>
  </div>
</div>
</form>
<?php
include_once 'dbConnection.php';
if(isset($_POST['singupteacherbutton'])){
  $user_email = htmlentities(mysqli_real_escape_string($con,$_POST['email']));
	$gender= htmlentities(mysqli_real_escape_string($con,$_POST['gender']));
  $name = htmlentities(mysqli_real_escape_string($con,$_POST['name']));
	$user_password = htmlentities(mysqli_real_escape_string($con,$_POST['password']));
  $insert = "insert into admin (email,gender,name,password) values ('$user_email','$gender','$name','$user_password')";

	$query = mysqli_query($con,$insert);

	if($query){

	echo "<script>alert('teacher has been added')</script>";


}}

?>

</div>
</div><!--container end-->
<!--Modal for admin login-->
	 <div class="modal fade" id="login">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title"><span style="color:black;font-family:'typo' "><center>Teacher Login</center></span></h4>
      </div>
      <div class="modal-body title1">
<div class="row">
<div class="col-md-3"></div>
<div class="col-md-6">
<form role="form" method="post" action="admin.php?q=index.php">
<div class="form-group">
<input type="text" name="uname" maxlength="20"  placeholder="Admin Email" class="form-control"/> 
</div>
<div class="form-group">
<input type="password" name="password" maxlength="15" placeholder="Password" class="form-control"/>
</div>
<div class="form-group" align="center">
<input type="submit" name="login" value="Login" class="btn btn-primary" style="border-radius:0%" />
</div>
</form>
</div><div class="col-md-3"></div></div>
      </div>
      <!--<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>-->
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--footer end-->


</body>

</html>
